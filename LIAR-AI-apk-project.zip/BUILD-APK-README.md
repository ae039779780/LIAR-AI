# LIAR·AI — Build APK Instructions

## Option 1: Android Studio (Recommended)

1. **Install Android Studio** from https://developer.android.com/studio
2. Open the `android/` folder as a project in Android Studio
3. Wait for Gradle sync to complete (may take a few minutes first time)
4. If prompted about SDK, click "Install" to install the required SDK
5. Go to **Build → Build Bundle(s) / APK(s) → Build APK(s)**
6. The APK will be in: `android/app/build/outputs/apk/debug/app-debug.apk`

## Option 2: Command Line

```bash
cd android
cp local.properties.template local.properties
# Edit local.properties and set your Android SDK path

# Build debug APK
./gradlew assembleDebug

# APK location:
# android/app/build/outputs/apk/debug/app-debug.apk
```

## Option 3: Online APK Builder

If you don't have Android Studio:

1. Go to https://appsgeyser.com or https://pwabuilder.com
2. Upload the `LIAR-AI-v3.html` file as a web app
3. Follow the wizard to generate an APK

## Permissions

The app requests these Android permissions:
- **RECORD_AUDIO** — Required for voice stress analysis (microphone access)
- **MODIFY_AUDIO_SETTINGS** — Required for audio processing configuration
- **INTERNET** — Required for Web Speech API (transcription)

## App Details

- **Package**: `com.liarai.app`
- **Min SDK**: Android 7.0 (API 24)
- **Target SDK**: Android 14 (API 34)
- **App Name**: LIAR AI
- **Theme**: Dark (#080808) with gold (#C9A84C) accents

## Project Structure

```
liar-ai-apk/
├── www/
│   └── index.html          ← LIAR·AI v3 web app
├── android/
│   ├── app/
│   │   └── src/main/
│   │       ├── AndroidManifest.xml  ← Permissions configured
│   │       ├── assets/public/       ← Web content (synced)
│   │       ├── java/.../MainActivity.java
│   │       └── res/                 ← Icons & splash screen
│   ├── build.gradle
│   ├── gradlew / gradlew.bat
│   └── local.properties.template
├── capacitor.config.json
└── BUILD-APK-README.md     ← This file
```

## Signing for Release

To create a signed APK for Google Play:

```bash
cd android
./gradlew assembleRelease
```

You'll need to configure signing in `android/app/build.gradle`:

```gradle
android {
    signingConfigs {
        release {
            storeFile file('your-keystore.jks')
            storePassword 'your-password'
            keyAlias 'your-alias'
            keyPassword 'your-key-password'
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

Generate a keystore:
```bash
keytool -genkey -v -keystore liar-ai.jks -keyalg RSA -keysize 2048 -validity 10000 -alias liarai
```
